<?php
namespace Eighteen\HelloData\Block;
class Index extends \Magento\Framework\View\Element\Template
{
    public function getHelloWorld()
    {
        return 'Hello World';
    }

}
